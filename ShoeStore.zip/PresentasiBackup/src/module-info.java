/**
 * 
 */
/**
 * @author User
 *
 */
module ProjectLecPresentasi {
	requires javafx.graphics;
	requires javafx.controls;
	requires java.sql;
	requires jfxtras.labs;
	requires javafx.base;
	exports Main to  javafx.graphics,javafx.fxml,jfxtras.labs;
	opens Main;
}