package Main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;



public class connection {
	private String USERNAME = "root";
	private String PASSWORD = "";
	private String DATABASE = "h";
	private String HOST = "localhost:3306";
	private String CONNECTION= String.format("jdbc:mysql://%s/%s", HOST, DATABASE);

	private Connection con;
	private Statement st;
	private static connection conn;
	
	public ResultSet res;
	public ResultSetMetaData resM;
	
	public ResultSet exeQuery(String q) {
		try {
			res = st.executeQuery(q);
			resM = res.getMetaData();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return res;
	}
	
	public void execUpdate (String q) {
		try {
			st.executeUpdate(q);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	public static connection getInstance() {
		if (conn == null) return new connection();
		return conn;
			
		
	}

	public connection () {
		
		try {
//			Class.forName("com.sql.jdbc.Driver");
			con = DriverManager.getConnection(CONNECTION,USERNAME,PASSWORD);
			st = con.createStatement();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		}

		
		
		
	}

