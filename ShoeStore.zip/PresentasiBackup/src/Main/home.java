package Main;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class home {
	BorderPane pane;
	Scene scene;
	MenuBar menuBar;
	Menu menu1, menu2;
	MenuItem menuItem1, menuItem2;
	VBox formLayout;
	Label insertLabel;
	StackPane stackPane;


	public home() {
		pane = new BorderPane(); // Layout
		stackPane = new StackPane();
		stackPane.getChildren().add(pane);

		pane.setStyle("-fx-background-color:#ffffff");


		scene = new Scene(stackPane, 700, 600); // Scenenya

		menuBar = new MenuBar();

		menu1 = new Menu("Menu");
		menu2 = new Menu("Report");

		menuItem1 = new MenuItem("Input/Sell Shoe");
		menuItem2 = new MenuItem("Logout");




		menuBar.getMenus().add(menu1);
		menu1.getItems().add(menuItem1);
		menu1.getItems().add(menuItem2);


		formLayout = new VBox(); //Layout form ditengah
		formLayout.setAlignment(Pos.CENTER);
		formLayout.setMaxWidth(250);
		insertLabel = new Label("SHOE STORES");
		insertLabel.setFont(Font.font("",FontWeight.BOLD,24));
		formLayout.getChildren().add(insertLabel);  


		pane.setTop(menuBar);
		pane.setCenter(formLayout);

		addAction();
		Main.gotoPage(scene);
	}

	public void addAction() {
		

		menuItem1.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				new InputShoe();
				
			}
		});
		

		menuItem2.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				new pagelogin();
				
			}
		});
	}


	
}
