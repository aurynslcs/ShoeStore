package Main;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class InputShoe   {
	
	private Scene scene; 
	
	 private GridPane gridpane; 
	 private Label titlelbl, namelbl, idlbl, sizelbl;
	 private TextField id, name,size;
	 private Button submit, deletebtn; 
	 private TableView <shoes> table;
	 
	 private connection con = connection.getInstance();
	 private Vector<shoes> cust;
	 BorderPane pane;
	 Scene sc;
	 MenuBar menuBar;
	 Menu menu1, menu2;
	 MenuItem menuItem1, menuItem2;
	 VBox formLayout;
	 Label insertLabel;
	 StackPane stackPane;
	 
	 public InputShoe() {
			pane = new BorderPane(); // Layout
			stackPane = new StackPane();
			stackPane.getChildren().add(pane);



			scene = new Scene(stackPane, 700, 600); // Scenenya

			menuBar = new MenuBar();

			menu1 = new Menu("Menu");

			menuItem1 = new MenuItem("Input/Sell Shoe");
			menuItem2 = new MenuItem("Logout");




			menuBar.getMenus().add(menu1);
			menuBar.getMenus().add(menu2);
			menu1.getItems().add(menuItem1);
			menu1.getItems().add(menuItem2);





			pane.setTop(menuBar);
			pane.setCenter(formLayout);
			Main.gotoPage(scene);



			addAction();
			init();
			layout();
			settable();
			Main.gotoPage(scene);
	 }

		public void addAction() {
			

			menuItem1.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent arg0) {
					new InputShoe();
					
				}
			});
			

			menuItem2.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent arg0) {
					new pagelogin();
					
				}
			});
		}

	 public void init () {
		 
		 gridpane = new GridPane();
		 
		 table = new TableView<>();
		 table.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
		
			 if (newValue != null) {
				id.setText(newValue.getId());
				name.setText(newValue.getName());
				size.setText(newValue.getSize());
			}
		 });
		 
		 titlelbl = new Label("Buy/sell shoes");
		 namelbl = new Label("Name : ");
		 idlbl = new Label("ID : ");
		 sizelbl = new Label("size : ");
		 
		 
		 
		 id = new TextField();
		 name = new TextField();
		 size = new TextField();
		 
		
		 
		 cust = new Vector<shoes> ();
		 submit = new Button("Add Data");
		 
		 submit.setOnAction(e -> {
			 	String ID = id.getText();
				String Name = name.getText();
				String Size = size.getText();
				addData(ID, Name, Size);
				refresh();
			});
		
		 deletebtn = new Button("delete");
		 
		 deletebtn.setOnAction(e -> {
			 	String ID = id.getText();
				String Name = name.getText();
				String Size = size.getText();
				String x = String.format("DELETE FROM shoes WHERE id = '%s' ",ID);
				con.execUpdate(x);
				refresh();
			});
	 }
	 
	 public void layout () {
		 pane.setCenter(gridpane);
		 pane.setBottom(table);
		 pane.setAlignment(titlelbl, Pos.CENTER);
		 pane.setMargin(titlelbl, new Insets (10));
		 
		 gridpane.add(idlbl, 0, 0);
		 gridpane.add(id, 1, 0);
		 
		 gridpane.add(namelbl, 0, 1);
		 gridpane.add(name, 1, 1);
		 
		 gridpane.add(sizelbl, 0, 2);
		 gridpane.add(size, 1, 2);
		 gridpane.add(submit, 0, 3);
		 
		 FlowPane btnpane = new FlowPane(submit, deletebtn);
		 gridpane.add(btnpane, 0, 3,2,1);
				 
		 gridpane.setVgap(5);
		 gridpane.setHgap(5);
	 }
	 
	 public void settable() {
		 TableColumn<shoes, String> idcolumn = new TableColumn<shoes, String>("Customer ID");
		 idcolumn.setCellValueFactory(new PropertyValueFactory<shoes, String>("id"));
		 idcolumn.setMinWidth(pane.getWidth()/3);
		 
		 TableColumn<shoes, String> namecolumn = new TableColumn<shoes, String>("shoes Name");
		 namecolumn.setCellValueFactory(new PropertyValueFactory<shoes, String>("name"));
		 namecolumn.setMinWidth(pane.getWidth()/3);
		 
		 TableColumn<shoes, String> sizecolumn = new TableColumn<shoes, String>("size");
		 sizecolumn.setCellValueFactory(new PropertyValueFactory<shoes, String>("size"));
		 sizecolumn.setMinWidth(pane.getWidth()/3);
		 
		 table.getColumns().addAll(idcolumn,namecolumn,sizecolumn);
		 
		 refresh();
	 }


	
	private void refresh() {
		getData();
		ObservableList<shoes> cusObs = FXCollections.observableArrayList(cust);
		table.setItems(cusObs);
	}
	
	private void getData () {
		cust.removeAllElements();
		
		String query = "SELECT * FROM shoes";
		con.res = con.exeQuery(query);
		
		try {
			while (con.res.next()) {
				String ID = con.res.getString("ID");
				String NAME = con.res.getString("Name");
				String SIZE = con.res.getString("size");
				
				cust.add(new shoes(ID,NAME,SIZE));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	private void addData (String id2, String name2, String size2 ) {
		String query = String.format("INSERT INTO shoes VALUES ('%s', '%s', '%s')", id2, name2, size2);
		con.execUpdate(query);

	}



}
